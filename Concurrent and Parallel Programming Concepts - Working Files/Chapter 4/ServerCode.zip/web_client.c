#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <stdlib.h>
#include <string.h>
#define BuffSize (4096)

void error_msg(const char* msg, int halt_flag) {
  perror(msg);
  if (halt_flag) exit(-1);
}
int main() {
  const int port = 80;  /* default port for a Web server */
  const char* request = 
    "GET /mkalin/index.html HTTP/1.1\nhost: condor.depaul.edu\n\n";
  struct sockaddr_in serv_addr;
  char               buffer[BuffSize + 1];
  
  /* Create descriptor for TCP socket. */
  int sock = socket(AF_INET, SOCK_STREAM, 0);            
  if (sock < 0) error_msg("Can't get socket descriptor.", -1);
  
  /* Fill in the fields of the server's address structure. */
  memset(&serv_addr, 0, sizeof(serv_addr)); /* Clear the structure. */
  serv_addr.sin_family = AF_INET;           /* address */
  /* Get the server information. */
  struct hostent* server = gethostbyname("condor.depaul.edu");
  if (0 == server) error_msg("No such host.", 1);
  /* Copy from the hostent structure into the server address structure. */
  bcopy((unsigned char*) server->h_addr, 
	(unsigned char*) &serv_addr.sin_addr.s_addr,
	server->h_length);
  serv_addr.sin_port = htons(port); /* host endian to network endian */
  
  /* Try to connect to the server. */
  if (connect(sock, (struct sockaddr*) &serv_addr, sizeof(serv_addr)) < 0) 
    error_msg("Can't connect.", 1);
  /* Write to the socket. */
  int n = write(sock, request, strlen(request));
  if (n < 0) error_msg("Can't write to socket.", 1);
  memset(buffer, 0, BuffSize + 1); /* clear the buffer for reading */
  /* Read from the socket and print to stdout */
  while (read(sock, buffer, BuffSize) > 0) printf("%s\n", buffer);
  if (close(sock) < 0) error_msg("Can't close socket.", 1);
  return 0;
}

